from flask import Flask, render_template, request, redirect, url_for, abort
import sqlite3

app = Flask(__name__)
DB_PATH = 'knowledge.db'

# Главная страница с формой поиска
def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

# Результаты поиска
@app.route('/search')
def search():
    query = request.args.get('q', '').strip()
    results = []
    if query:
        conn = get_db_connection()
        cur = conn.execute('SELECT rowid, title, content FROM documents')
        docs = cur.fetchall()
        conn.close()
        for doc in docs:
            lines = doc['content'].splitlines()
            matches = []
            for idx, line in enumerate(lines):
                if query.lower() in line.lower():
                    matches.append({'text': line, 'line_num': idx})
            if matches:
                results.append({
                    'rowid': doc['rowid'],
                    'title': doc['title'],
                    'matches': matches
                })
    return render_template('search.html', query=query, results=results)

# Просмотр полного текста документа
@app.route('/doc/<int:doc_id>')
def view_doc(doc_id):
    line_num = request.args.get('line', type=int)
    conn = get_db_connection()
    cur = conn.execute('SELECT rowid, title, content FROM documents WHERE rowid = ?', (doc_id,))
    doc = cur.fetchone()
    conn.close()
    if not doc:
        abort(404)
    lines = doc['content'].splitlines()
    return render_template('doc.html', doc=doc, lines=lines, line_num=line_num)

if __name__ == '__main__':
    app.run(debug=True) 