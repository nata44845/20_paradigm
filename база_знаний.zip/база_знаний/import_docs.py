import os
import sqlite3

DB_PATH = 'knowledge.db'
DOCS_DIR = 'docs'

# Создание базы данных и таблицы с поддержкой полнотекстового поиска
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()
c.execute('''
CREATE VIRTUAL TABLE IF NOT EXISTS documents USING fts5(
    title,
    content
)
''')

# Импорт всех .txt файлов из папки docs
for filename in os.listdir(DOCS_DIR):
    if filename.endswith('.txt'):
        path = os.path.join(DOCS_DIR, filename)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        c.execute('INSERT INTO documents (title, content) VALUES (?, ?)', (filename, content))
        print(f'Импортирован: {filename}')

conn.commit()
conn.close()
print('Импорт завершён.') 